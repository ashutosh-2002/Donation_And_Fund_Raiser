# Donation-and-Fund-Raiser

This is an donation and fund raising website. You can either ask for donation if you need some or donate money if you want to donate.

If you want donation first you need to fill out the receiver registration form available in our website. Then it will be sent to our admin where he will verify your request for donation and approve only if he find your request for donation geniune. Admin have total rights to either accept or reject your request for donation.Once admin will approve your request for donation you will be our verified recivier and your details will be shown on our website and people will able to donate you.

Donor has to simply look on the receivers list section and donate to that person directly with the information provided there. And then he has to provide the information to the admin by filling the form donor registration and if find genuine, receivers money will be updated by admin and his/her name will be on the donors list. You have to take screenshot of successful donation in reciever bank account and upload it in google drive (shared publically). You have to provide link of google drive in donor registration form as a proof of donation.

This is a group project developed by three students of Pandit Dwarrka Prasad Mishra Indian Institute of Information Technology , Jabalpur , Madhya Pradesh , India. The students are Arpit Gupta  , Ashray Jain  and Ashutosh.
